﻿using FinalRevise.Entity;
using FinalRevise.Service;
using Microsoft.AspNetCore.Mvc;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;

namespace FinalRevise.Controllers
{
    //localhost:8080/api/usercontroller/users

    [Route("/api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet("/users")]
        public async Task<List<User>> GetAllUsers()
        {
            return await _userService.GetAllUsers();
        }

        [HttpPost("/users")]
        public void Post([FromBody] User user)
        {
            _userService.AddUser(user);
        }

    }
}
