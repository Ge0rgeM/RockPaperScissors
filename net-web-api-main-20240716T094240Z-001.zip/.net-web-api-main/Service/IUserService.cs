﻿using FinalRevise.Entity;

namespace FinalRevise.Service
{
    public interface IUserService
    {
        public Task<List<User>> GetAllUsers();
        public void AddUser(User user);
        public User UpdateUser(User user, int id);
        public User DeleteUser(int id);
        public Task<User> GetUserById(int id);
    }
}
