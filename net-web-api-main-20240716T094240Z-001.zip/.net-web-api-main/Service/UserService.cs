﻿using FinalRevise.CustomException;
using FinalRevise.Entity;
using FinalRevise.Repository;
using Microsoft.EntityFrameworkCore;

namespace FinalRevise.Service
{
    public class UserService : IUserService
    {
        private readonly AppDbContenxt _context;
        

        public UserService(AppDbContenxt context)
        {
            _context = context;
        }

        public void AddUser(User user)
        {
            _context.users.Add(user);
            _context.SaveChanges();
        }

        public User DeleteUser(int id)
        {
            var user = _context.users.FirstOrDefault(p => p.Id == id);
            if (user != null)
            {
                _context.users.Remove(user);
                _context.SaveChanges();
                return user;
            }

            throw new UserException($"User with {id} not found");
        }

        public async Task<List<User>> GetAllUsers()
        {
            return await _context.users.ToListAsync();
        }

        public async Task<User> GetUserById(int id)
        {
            var user = await _context.users.FirstOrDefaultAsync(p => p.Id == id);

            if (user != null)
            {
                return user;
            }

            throw new UserException($"User with {id} not found");
        }

        public User UpdateUser(User user, int id)
        {
            var foundUser = _context.users.FirstOrDefault(p => p.Id == id);

            if (user != null)
            {
                foundUser.Name = user.Name;
                foundUser.Email = user.Email;
                _context.SaveChanges();
                return foundUser;
                
            }

            throw new UserException("User can't be updated");
        }
    }
}
