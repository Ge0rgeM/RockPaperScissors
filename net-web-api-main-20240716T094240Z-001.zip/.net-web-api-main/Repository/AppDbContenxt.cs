﻿using FinalRevise.Entity;
using Microsoft.EntityFrameworkCore;

namespace FinalRevise.Repository
{
    public class AppDbContenxt : DbContext
    {

        public AppDbContenxt(DbContextOptions<AppDbContenxt> options) : base(options) 
        {

        }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase("UserDatabase");
        }

        public DbSet<User> users { get; set; }
        public DbSet<Product> products { get; set; }
    }
}
